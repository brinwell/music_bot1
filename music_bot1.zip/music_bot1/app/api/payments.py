from fastapi import APIRouter
from config import STRIPE_API_KEY, YOOMONEY_API_KEY, QIWI_API_KEY
import stripe

router = APIRouter()

stripe.api_key = STRIPE_API_KEY

@router.post("/create-payment")
async def create_payment(amount: int, currency: str = "USD"):
    intent = stripe.PaymentIntent.create(
        amount=amount * 100,
        currency=currency
    )
    return {"client_secret": intent["client_secret"]}
