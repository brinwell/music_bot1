import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
GENIUS_API_KEY = os.getenv("GENIUS_API_KEY")
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")
SHZAM_API_KEY = os.getenv("SHZAM_API_KEY")
DATABASE_URL = os.getenv("DATABASE_URL")
STRIPE_API_KEY = os.getenv("STRIPE_API_KEY")
YOOMONEY_API_KEY = os.getenv("YOOMONEY_API_KEY")
QIWI_API_KEY = os.getenv("QIWI_API_KEY")
ACR_ACCESS_KEY = os.getenv("ACR_ACCESS_KEY")
ACR_ACCESS_SECRET = os.getenv("ACR_ACCESS_SECRET")