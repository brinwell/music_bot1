from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

# Кнопка "Назад"
back_button = KeyboardButton(text="🔙 Назад")

# Главное меню
start_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🔍 Найти музыку"), KeyboardButton(text="🎶 Плейлист")],
        [KeyboardButton(text="⬇ Скачать"), KeyboardButton(text="🎤 Определить песню")],
    ],
    resize_keyboard=True,
    one_time_keyboard=True
)

# Клавиатура только с кнопкой "Назад"
only_back_keyboard = ReplyKeyboardMarkup(
    keyboard=[[back_button]],
    resize_keyboard=True,
    one_time_keyboard=True
)

def get_start_keyboard():
    """Возвращает главную клавиатуру меню"""
    print("[INFO] Главная клавиатура загружена")
    return start_keyboard

def get_only_back_keyboard():
    """Возвращает клавиатуру с кнопкой 'Назад'"""
    print("[INFO] Клавиатура с кнопкой 'Назад' загружена")
    return only_back_keyboard