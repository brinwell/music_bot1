from fastapi import APIRouter
import requests
from config import SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET, GENIUS_API_KEY

router = APIRouter()

@router.get("/search")
async def search_music(query: str):
    headers = {"Authorization": f"Bearer {SPOTIFY_CLIENT_SECRET}"}
    params = {"q": query, "type": "track", "limit": 1}
    response = requests.get("https://api.spotify.com/v1/search", headers=headers, params=params)
    return response.json()
