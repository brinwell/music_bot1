import os
import aiohttp
import asyncio
import base64
from functools import partial
from aiogram import Dispatcher, types, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.filters import Command
from aiogram.types import FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup
from config import SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET
from keyboards import get_start_keyboard, get_only_back_keyboard
from admin import get_admin_keyboard, get_stats, clear_downloads
import logging
from concurrent.futures import ThreadPoolExecutor
import speech_recognition as sr
from pydub import AudioSegment
from shazamio import Shazam
import yt_dlp

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Константы
TEMP_DIR = "downloads"
AUDIO_DIR = "audio"
ADMIN_ID = 6441714467
SPOTIFY_AUTH_URL = "https://accounts.spotify.com/api/token"
SPOTIFY_SEARCH_URL = "https://api.spotify.com/v1/search"

# Глобальные переменные
_spotify_token_cache = None
_token_expiry = None
_executor = ThreadPoolExecutor(max_workers=2)

# Создание директорий
os.makedirs(TEMP_DIR, exist_ok=True)
os.makedirs(AUDIO_DIR, exist_ok=True)

# Состояния бота
class BotState(StatesGroup):
    main_menu = State()
    search_music = State()
    playlist = State()
    download = State()
    shazam = State()

# Конфигурация
PLAYLISTS = {
    "Весёлый": "https://open.spotify.com/playlist/37i9dQZF1DX3rxVfibe1L0",
    "Грустный": "https://open.spotify.com/playlist/37i9dQZF1DX7qK8ma5wgG1",
    "Спортивный": "https://open.spotify.com/playlist/37i9dQZF1DX70RN3TfWWJh"
}

ACTION_CONFIG = {
    "🔍 Найти музыку": {"state": BotState.search_music, "text": "Введите название песни или исполнителя:"},
    "🎶 Плейлист": {"state": BotState.playlist, "text": "Выберите категорию плейлиста 🎶\n\n- Весёлый\n- Грустный\n- Спортивный"},
    "⬇ Скачать": {"state": BotState.download, "text": "Введите ссылку на YouTube или Spotify для скачивания ⬇"},
    "🎤 Определить песню": {"state": BotState.shazam, "text": "🎤 Отправьте голосовое сообщение, и я попробую найти песню!"}
}

# Утилитные функции
async def get_spotify_token():
    global _spotify_token_cache, _token_expiry
    current_time = asyncio.get_event_loop().time()
    
    if _spotify_token_cache and _token_expiry and _token_expiry > current_time:
        return _spotify_token_cache

    auth_string = base64.b64encode(f"{SPOTIFY_CLIENT_ID}:{SPOTIFY_CLIENT_SECRET}".encode()).decode()
    headers = {"Authorization": f"Basic {auth_string}", "Content-Type": "application/x-www-form-urlencoded"}
    data = {"grant_type": "client_credentials"}

    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
            async with session.post(SPOTIFY_AUTH_URL, headers=headers, data=data) as response:
                if response.status != 200:
                    logger.error(f"Spotify auth error: {await response.text()}")
                    return None
                data = await response.json()
                _spotify_token_cache = data["access_token"]
                _token_expiry = current_time + 3500
                return _spotify_token_cache
    except Exception as e:
        logger.error(f"Spotify token error: {e}")
        return None

async def search_spotify(query: str):
    token = await get_spotify_token()
    if not token:
        return None, "❌ Ошибка авторизации Spotify."

    headers = {"Authorization": f"Bearer {token}"}
    params = {"q": query, "type": "track", "limit": 1}

    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
            async with session.get(SPOTIFY_SEARCH_URL, headers=headers, params=params) as response:
                if response.status != 200:
                    return None, f"❌ Ошибка Spotify API: {response.status}"
                data = await response.json()
                tracks = data.get("tracks", {}).get("items", [])
                if not tracks:
                    return None, "❌ Ничего не найдено."
                track = tracks[0]
                return f"{track['name']} - {track['artists'][0]['name']}", track["external_urls"]["spotify"]
    except Exception as e:
        logger.error(f"Spotify search error: {e}")
        return None, "❌ Ошибка поиска."

async def download_youtube(search_query: str):
    safe_query = "".join(c for c in search_query if c.isalnum() or c in " -_")[:50]
    file_path = os.path.join(TEMP_DIR, f"{safe_query}.mp3")
    ydl_opts = {
        "format": "bestaudio/best",
        "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}],
        "outtmpl": file_path.replace(".mp3", ""),
        "quiet": True,
        "default_search": "ytsearch1",
        "noplaylist": True,
    }

    try:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(_executor, partial(yt_dlp.YoutubeDL(ydl_opts).download, [search_query]))
        return file_path if os.path.exists(file_path) else None
    except Exception as e:
        logger.error(f"Download error: {e}")
        return None

async def recognize_speech(file_path):
    recognizer = sr.Recognizer()
    try:
        audio = AudioSegment.from_file(file_path)
        wav_path = file_path.replace(".oga", ".wav")
        audio.export(wav_path, format="wav")

        with sr.AudioFile(wav_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data, language="ru-RU")
            os.remove(wav_path)
            return text
    except (sr.UnknownValueError, sr.RequestError) as e:
        logger.error(f"Speech recognition error: {e}")
        return None
    except Exception as e:
        logger.error(f"Audio processing error: {e}")
        return None

async def search_by_audio_shazam(file_path):
    try:
        shazam = Shazam()
        result = await shazam.recognize_song(file_path)

        if not result or "track" not in result:
            return None, None

        track = result["track"]
        title = f"{track['title']} - {track['subtitle']}"
        link = track.get('share', {}).get('href', 'Ссылка недоступна')
        return title, link
    except Exception as e:
        logger.error(f"Shazam error: {e}")
        return None, None

async def cleanup_file(file_path: str, delay: int = 60):
    await asyncio.sleep(delay)
    if os.path.exists(file_path):
        os.remove(file_path)
        logger.info(f"File deleted: {file_path}")

# Регистрация обработчиков
def register_handlers(dp: Dispatcher):
    @dp.message(Command("start"))
    async def start_command(message: types.Message, state: FSMContext):
        await state.set_state(BotState.main_menu)
        await message.answer("Привет! Я музыкальный бот. 🎵 Выберите действие:", reply_markup=get_start_keyboard())

    @dp.message(Command("admin"))
    async def admin_command(message: types.Message, state: FSMContext):
        if message.from_user.id != ADMIN_ID:
            await message.answer("❌ Доступ запрещён!")
            return
        await message.answer("Админ-панель:", reply_markup=get_admin_keyboard())

    @dp.callback_query(F.data.startswith("admin_"))
    async def admin_callback(callback: types.CallbackQuery):
        action = callback.data.split("_")[1]
        actions = {
            "restart": "🔄 Перезапуск...",
            "clear_downloads": clear_downloads(),
            "stats": get_stats()
        }
        await callback.message.edit_text(actions.get(action, "Неизвестная команда"), reply_markup=get_admin_keyboard())
        await callback.answer()

    @dp.message(F.text.in_(ACTION_CONFIG.keys()))
    async def process_button_click(message: types.Message, state: FSMContext):
        config = ACTION_CONFIG[message.text]
        await state.set_state(config["state"])
        await message.answer(config["text"], reply_markup=get_only_back_keyboard())

    @dp.message(F.text == "🔙 Назад")
    async def process_back(message: types.Message, state: FSMContext):
        await state.set_state(BotState.main_menu)
        await message.answer("Привет! Я музыкальный бот. 🎵 Выберите действие:", reply_markup=get_start_keyboard())

    @dp.message(F.text.regexp(r"(?i)(песня из рекламы|из фильма|из сериала)"))
    async def ai_suggestion_handler(message: types.Message, state: FSMContext):
        query = message.text.lower()
        suggestions = {
            "песня из рекламы nike": "Sweet Dreams - Eurythmics",
            "песня из фильма": "My Heart Will Go On - Celine Dion",
            "песня из сериала": "I'll Be There for You - The Rembrandts"
        }
        for key, suggestion in suggestions.items():
            if key in query:
                await message.answer(f"Может быть, это: {suggestion}? Попробуй поискать!")
                return
        await message.answer("Не могу ничего подсказать. Попробуй описать точнее!")

    @dp.message(BotState.search_music)
    async def handle_search_query(message: types.Message, state: FSMContext):
        query = message.text.strip()
        if not query:
            await message.answer("Пожалуйста, введите непустой запрос.")
            return

        search_msg = await message.answer(f"🔍 Ищем: {query}...")
        title, link = await search_spotify(query)

        if not title:
            await search_msg.edit_text(link)
            return

        await search_msg.edit_text(f"🎵 Найдено: {title}\n🔗 {link}")
        markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬇ Скачать", callback_data=f"download:{title}")]])
        await message.answer("Хотите скачать этот трек?", reply_markup=markup)

    @dp.message(BotState.playlist)
    async def handle_playlist(message: types.Message, state: FSMContext):
        category = message.text.strip()
        if link := PLAYLISTS.get(category):
            await message.answer(f"🎵 Вот плейлист **{category}**:\n🔗 {link}")
        else:
            await message.answer("❌ Неверная категория. Выберите из списка.")

    @dp.message(BotState.download)
    async def handle_download(message: types.Message, state: FSMContext):
        url = message.text.strip()
        if "spotify.com" not in url and "youtube.com" not in url:
            await message.answer("❌ Неверная ссылка.")
            return

        msg = await message.answer("⏳ Скачиваю...")
        file_path = await download_youtube(url)
        if file_path:
            await message.answer_document(FSInputFile(file_path))
            asyncio.create_task(cleanup_file(file_path))
        else:
            await msg.edit_text("❌ Не удалось скачать.")

    @dp.callback_query(F.data.startswith("download:"))
    async def process_download_callback(callback: types.CallbackQuery, state: FSMContext):
        title = callback.data.split(":", 1)[1]
        await callback.answer("⏳ Скачиваю...")
        msg = await callback.message.answer(f"⏳ Скачиваю: {title}...")
        file_path = await download_youtube(title)
        if file_path:
            await callback.message.answer_document(FSInputFile(file_path))
            asyncio.create_task(cleanup_file(file_path))
        else:
            await msg.edit_text("❌ Не удалось скачать.")
        await msg.delete()

    @dp.message(F.voice, BotState.shazam)
    async def handle_voice(message: types.Message, state: FSMContext):
        file_id = message.voice.file_id
        file = await message.bot.get_file(file_id)
        file_path = os.path.join(AUDIO_DIR, f"{file_id}.oga")

        # Скачиваем голосовое сообщение
        await message.bot.download_file(file.file_path, file_path)
        
        msg = await message.answer("🎤 Распознаю песню...")
        
        # Пробуем Shazam
        title, link = await search_by_audio_shazam(file_path)
        
        if title:
            await msg.edit_text(f"🎵 Найдено: {title}\n🔗 {link}")
            file_path_download = await download_youtube(title)
            if file_path_download:
                await message.answer_document(FSInputFile(file_path_download))
                asyncio.create_task(cleanup_file(file_path_download))
            else:
                await message.answer("❌ Не удалось скачать песню.")
        else:
            # Если Shazam не сработал, пробуем распознавание речи
            text = await recognize_speech(file_path)
            if text:
                await msg.edit_text(f"🎤 Распознано: {text}\nИщу песню...")
                title, link = await search_spotify(text)
                if title:
                    await message.answer(f"🎵 Найдено: {title}\n🔗 {link}")
                    file_path_download = await download_youtube(title)
                    if file_path_download:
                        await message.answer_document(FSInputFile(file_path_download))
                        asyncio.create_task(cleanup_file(file_path_download))
                    else:
                        await message.answer("❌ Не удалось скачать песню.")
                else:
                    await msg.edit_text("❌ Не удалось найти песню по тексту.")
            else:
                await msg.edit_text("❌ Не удалось распознать песню или текст.")

        asyncio.create_task(cleanup_file(file_path))

    logger.info("Все обработчики зарегистрированы")