# bot/admin.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import os

def get_admin_keyboard():
    """Возвращает клавиатуру для админ-панели"""
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Рестарт", callback_data="admin_restart")],
        [InlineKeyboardButton(text="🧹 Очистить загрузки", callback_data="admin_clear_downloads")],
        [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")]
    ])
    return keyboard

def get_stats():
    """Возвращает базовую статистику"""
    downloads_size = sum(os.path.getsize(os.path.join("downloads", f)) for f in os.listdir("downloads") if os.path.isfile(os.path.join("downloads", f)))
    audio_size = sum(os.path.getsize(os.path.join("audio", f)) for f in os.listdir("audio") if os.path.isfile(os.path.join("audio", f)))
    return f"📊 Статистика:\n" \
           f"Размер папки downloads: {downloads_size / 1024:.2f} KB\n" \
           f"Размер папки audio: {audio_size / 1024:.2f} KB\n" \
           f"Всего файлов в downloads: {len(os.listdir('downloads'))}\n" \
           f"Всего файлов в audio: {len(os.listdir('audio'))}"

def clear_downloads():
    """Очищает папки downloads и audio"""
    for folder in ["downloads", "audio"]:
        for file in os.listdir(folder):
            file_path = os.path.join(folder, file)
            if os.path.isfile(file_path):
                os.remove(file_path)
    return "🧹 Все загрузки очищены!"