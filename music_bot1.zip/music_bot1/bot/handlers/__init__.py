from aiogram import Dispatcher
from .handlers import register_handlers

def register_handler(dp: Dispatcher):
    register_handlers(dp)
